﻿/*
 * Auteur : Paschoud Nicolas
 * Date : 11 Avril 2016
 * Nom de l'application : calculDeFonctions
 * Description : Calcul des fonctions que l'utilisateur rentre, 
 *               et la dessine sur un graphique
 * Version : 1.0
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace calculDeFonctions
{
    public partial class frmMainFonction : Form
    {

        public frmMainFonction()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
        }

        //   Initialisation des variables
        ArrayList arrayFonctions = new ArrayList();
        public int selectedIndex = 0;
        public bool validerModif = false;
        const int decalageCadrillage = 10;

        class Fonction
        {
            public string equation;
            public string sommet;
            public string zeros;
            public string ordonnee;
            public Color couleur;
            private int status = -20;
            public int nbrCalculs = 20;
            public List<Point> listPoint = new List<Point>();
            public Point depart;
            public Point premier;
            public Point second;
            public Point dernier;

            //  Constructor:
            public Fonction(string Equation, Color Couleur)
            {
                this.equation = Equation;
                this.couleur = Couleur;
            }

            public void calculerSommet()
            {
                this.sommet = "0";
            }

            public void calculerZeros()
            {
                StringBuilder equation = new StringBuilder(this.equation);

                equation = this.remplacerChiffre(this.status.ToString());

                double resultat = Convert.ToDouble(this.calcul(equation));

                Console.WriteLine("x : " + status + "; Y : " + resultat);

                //if (status == -20)
                //{
                    //this.depart = new Point(350,350);
                //}

                if (status == 20)
                {
                    this.dernier = new Point((((int)resultat * 10) / 1) + 350, ((status * 10) / 1) + 350);
                }

                if (resultat == 0)
                {
                    this.zeros += status.ToString() + ", ";
                }

                if (status < nbrCalculs)
                {
                    status++;
                    this.calculerZeros();
                }
            }

            public void calculerOrdonnee()
            {
                StringBuilder equation = new StringBuilder(this.equation);

                equation = this.remplacerChiffre("0");


                double resultat = Convert.ToDouble(this.calcul(equation));

                this.depart = new Point(350, ((int)resultat / 10)+350);

                this.ordonnee = resultat.ToString();
            }

            //  Trouver le chiffre -    -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -
            public double trouverChiffre(int emplacement, StringBuilder equation)
            {
                int i = emplacement;

                string chiffreRetour = string.Empty;

                do
                {
                    //  Si l'élément i de equation, est un chiffre
                    if (char.IsNumber(equation[i]))
                    {
                        //  Alors, on l'ajoute au résultat de retour
                        chiffreRetour += equation[i];
                    }

                    i++;

                    if (i == equation.Length)
                    {
                        break;
                    }
                } while (char.IsNumber(equation[i]));

                return Convert.ToDouble(chiffreRetour);
            }

            //  Remplacer le chiffre    -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -  -   -   -   -   -
            private StringBuilder remplacerChiffre(string chiffre)
            {
                int i = 0;
                StringBuilder equation = new StringBuilder();

                foreach (char elementX in this.equation)
                {
                    if (Convert.ToInt32(chiffre) >= 0 && i == 0)
                    {
                        equation.Append('+');
                    }

                    if (elementX == 'x')
                    {
                        StringBuilder chiffreTest = new StringBuilder(chiffre);
                        if (i != 0 && i < equation.Length)
                        {
                            switch (equation[i])
                            {
                                case '+':
                                    if (chiffre[0] == '-')
                                    {
                                        equation.Remove(i, 1);
                                    }
                                    if (chiffre[0] == '+')
                                    {
                                        equation.Remove(i, 1);
                                    }
                                    break;
                                case '-':
                                    if (chiffre[0] == '-')
                                    {
                                        equation.Remove(i, 1);
                                        chiffreTest.Remove(0, 1);
                                    }
                                    if (chiffre[0] == '+')
                                    {
                                        equation.Remove(i, 1);
                                    }
                                    break;
                            }
                        }
                        equation.Append(chiffreTest);
                    }
                    else
                    {
                        equation.Append(elementX);
                    }
                    i++;
                }
                Console.WriteLine("Equation : " + equation);
                return equation;
            }

            private double calcul(StringBuilder equation)
            {
                int i = 0;
                double resultat = 0;
                double chiffre = 0;

                for (i = 0; i < equation.Length; i++)
                {
                    if (!char.IsNumber(equation[i]))
                    {
                        chiffre = this.trouverChiffre(i + 1, equation);

                        switch (equation[i])
                        {
                            case '+':
                                resultat += chiffre;
                                break;
                            case '-':
                                resultat -= chiffre;
                                break;
                            case '*':
                                resultat *= chiffre;
                                break;
                            case '/':
                                resultat += 0;
                                break;
                        }
                    }
                }
                return resultat;
            }

            public void calculPoint(){

            }
        }

        /// <summary>
        /// Evénement se produisant lorsqu'on clique sur "A Propos"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tsmAideAPropos_Click(object sender, EventArgs e)
        {
            //  Instantiation de la fenêtre frmAbouBox
            frmAboutBox FrmAboutBox = new frmAboutBox();

            //  Affichage de la fenêtre "A Propos"
            FrmAboutBox.ShowDialog();
        }

        /// <summary>
        /// Evénement se produisant à la fermeture de l'application
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmMainFonction_FormClosing(object sender, FormClosingEventArgs e)
        {
            //  Affichage d'un messsage box + récupération de la réponse
            DialogResult reponse = MessageBox.Show("Etes-vous sur de vouloir quitter l'application ?", "Quitter l'application ?", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            //  Si l'utilisateur dit non
            if (reponse == DialogResult.No)
            {
                //  On annule la fermeture de l'application
                e.Cancel = true;
            }
        }

        /// <summary>
        /// Evénement se produisant lorsque l'on clique sur le boutton "Ajouter"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAjouter_Click(object sender, EventArgs e)
        {
            //  Equation de l'utilisateur
            string equation = string.Empty;

            //  Si l'utilisateur ne veut modifier sa fonction
            if (!validerModif)
            {// Alors, cela veut dire qu'il veut la créée
                //  Ajout de la fonction dans la listBox
                lsbFonctions.Items.Add(tbxFonctionUser.Text);
                equation = tbxFonctionUser.Text;
            }
            else
            {// Sinon on rajoute la fonction

                //  Ajout de la fonction dans la listBox
                lsbFonctions.Items.Add(tbxModifFonction.Text);

                //  On récupère l'équation
                equation = tbxModifFonction.Text;

                validerModif = false;
            }

            //  Instanciation de la calss fonction
            Fonction fonctionNative = new Fonction(equation, Color.Black);

            btnColor.BackColor = fonctionNative.couleur;

            fonctionNative.calculerSommet();

            fonctionNative.calculerZeros();

            fonctionNative.calculerOrdonnee();



            if (fonctionNative.zeros == string.Empty)
            {
                fonctionNative.zeros = "N/A";
            }
            //   Ajout de la fonction de l'utilisateur
            arrayFonctions.Add(fonctionNative);

            pbxGraphics.Refresh();

            //  Supression du contenu de la textBox
            tbxFonctionUser.Text = string.Empty;
        }

        /// <summary>
        /// Evénement se produisant lorsque l'on clique sur Supprimer
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSupprimer_Click(object sender, EventArgs e)
        {
            //  Supression de l'item sélectionner
            lsbFonctions.Items.RemoveAt(selectedIndex);

            //   Suppresion de la fonction dans le tableau
            arrayFonctions.RemoveAt(selectedIndex);
        }


        /// <summary>
        /// Evénement se produisant lorsque l'on modifie le contenu d'un textBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbxFonctionUser_TextChanged(object sender, EventArgs e)
        {
            //  Si la textBox contient du texte...
            if (tbxFonctionUser.Text != string.Empty)
            {
                //  Alors on active le boutton d'ajout
                btnAjouter.Enabled = true;
            }
            else
            {   //  Sinon on désactive le boutton
                //  pour ne pas faire planter le programme
                btnAjouter.Enabled = false;
            }
        }

        /// <summary>
        /// Evénement se produisant lorsque l'on séléctionne un item de la listBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lsbFonctions_SelectedIndexChanged(object sender, EventArgs e)
        {
            //   Si un item de la listeBox est séléctionné,
            if (lsbFonctions.SelectedItem != null)
            {
                //  alors,  on active le boutton surpprimer
                btnSupprimer.Enabled = true;

                //  Activation des propriétés
                gbxProperties.Enabled = true;

                //  Mise en mémoire de l'index séléctionner
                //  Au cas ou on voudrait supprimer
                selectedIndex = lsbFonctions.SelectedIndex;

                //  Récupération de la fonction sélectionnée, pour afficher ses paramètre
                Fonction laFonction = (Fonction)arrayFonctions[selectedIndex];

                #region Afficher Infos Fonctions
                //  Affichage du Sommet
                lblSommet.Text = laFonction.sommet;

                //  Affichage de l'ordonnée
                lblOrdonnee.Text = laFonction.ordonnee;

                //  Affichages du zéro
                lblZeros.Text = laFonction.zeros;

                //  Modification de la couleur du boutton
                btnColor.BackColor = laFonction.couleur;

                //  On met l'equation dans la textBox pour la modifier
                tbxModifFonction.Text = laFonction.equation;
                #endregion
            }
            else
            {
                //   Sinon on désactive le boutton supprimer
                btnSupprimer.Enabled = false;
                gbxProperties.Enabled = false;
            }
        }

        private void btnColor_Click(object sender, EventArgs e)
        {
            //   Ouverture de la form pour choisir sa couleur
            cdlColorFonction.ShowDialog();

            //   On change la couleur du boutton
            btnColor.BackColor = cdlColorFonction.Color;

            Fonction laFonction = (Fonction)arrayFonctions[selectedIndex];

            //  Mise a jour de la couleur choisit par l'utilisateur
            laFonction.couleur = cdlColorFonction.Color;

        }

        private void btnValiderModif_Click(object sender, EventArgs e)
        {
            //  Mise a jour des valeurs de la fonction 
            //  que l'utilisateur veut modifier
            validerModif = true;
            btnSupprimer_Click(null, null);
            btnAjouter_Click(null, null);
        }

        private void pbxGraphics_Paint(object sender, PaintEventArgs e)
        {
            Pen penAxes = new Pen(Color.Black, 3);
            Pen penCadrillage = new Pen(Color.Gray, 1);

            #region Afficher graphique

            for (int i = 0; i <= pbxGraphics.Width; i += decalageCadrillage)
            {
                e.Graphics.DrawLine(penCadrillage, i, 0, i, pbxGraphics.Height);
            }

            for (int i = 0; i <= pbxGraphics.Width; i += decalageCadrillage)
            {
                e.Graphics.DrawLine(penCadrillage, 0, i, pbxGraphics.Width, i);
            }

            #endregion

            /*int debut = 100;
            int Unmoitier = 100;
            int Deuxmoitier = 100;
            int fin = 100;

            // Create start and sweep angles.
            int startAngle = 100;
            int sweepAngle = 180;*/

            Pen penBezier = new Pen(Color.Red, 4);
            
            if (arrayFonctions != null)
            {

                for (int i = 0; i < arrayFonctions.Count; i++)
                {
                    Fonction laFonction = (Fonction)arrayFonctions[i];
                    e.Graphics.DrawBezier(penBezier, laFonction.depart, laFonction.premier, new Point(0, 0), laFonction.dernier);                
                }
            }

            //  Dessine les axes
            e.Graphics.DrawLine(penAxes, pbxGraphics.Width / 2, 0, pbxGraphics.Height / 2, pbxGraphics.Width);
            e.Graphics.DrawLine(penAxes, 0, pbxGraphics.Height / 2, pbxGraphics.Width, pbxGraphics.Height / 2);
        }


        private void frmMainFonction_Load(object sender, EventArgs e)
        {
            pbxGraphics.Refresh();
        }

        private void tbxFonctionUser_KeyPress(object sender, KeyPressEventArgs e)
        {
            //   Si le caractère est une lettre, alors 
            if (char.IsLetter(e.KeyChar))
            {
                //   On la change en x
                e.KeyChar = 'x';
            }
        }
    }
}