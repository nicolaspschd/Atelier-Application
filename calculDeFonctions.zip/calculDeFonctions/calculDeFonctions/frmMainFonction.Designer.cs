﻿namespace calculDeFonctions
{
    partial class frmMainFonction
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMainFonction));
            this.tbxFonctionUser = new System.Windows.Forms.TextBox();
            this.msMain = new System.Windows.Forms.MenuStrip();
            this.tsmAide = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmAideAPropos = new System.Windows.Forms.ToolStripMenuItem();
            this.btnAjouter = new System.Windows.Forms.Button();
            this.btnSupprimer = new System.Windows.Forms.Button();
            this.cbxAfficher = new System.Windows.Forms.CheckBox();
            this.lsbFonctions = new System.Windows.Forms.ListBox();
            this.gbxProperties = new System.Windows.Forms.GroupBox();
            this.btnValiderModif = new System.Windows.Forms.Button();
            this.tbxModifFonction = new System.Windows.Forms.TextBox();
            this.lblZeros = new System.Windows.Forms.Label();
            this.lblInfoZero = new System.Windows.Forms.Label();
            this.lblOrdonnee = new System.Windows.Forms.Label();
            this.lblInfoOrdonnee = new System.Windows.Forms.Label();
            this.lblSommet = new System.Windows.Forms.Label();
            this.lblInfoSommet = new System.Windows.Forms.Label();
            this.lblColor = new System.Windows.Forms.Label();
            this.btnColor = new System.Windows.Forms.Button();
            this.cdlColorFonction = new System.Windows.Forms.ColorDialog();
            this.pbxGraphics = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.msMain.SuspendLayout();
            this.gbxProperties.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGraphics)).BeginInit();
            this.SuspendLayout();
            // 
            // tbxFonctionUser
            // 
            this.tbxFonctionUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxFonctionUser.Location = new System.Drawing.Point(12, 32);
            this.tbxFonctionUser.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxFonctionUser.Name = "tbxFonctionUser";
            this.tbxFonctionUser.Size = new System.Drawing.Size(215, 30);
            this.tbxFonctionUser.TabIndex = 1;
            this.tbxFonctionUser.TextChanged += new System.EventHandler(this.tbxFonctionUser_TextChanged);
            this.tbxFonctionUser.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxFonctionUser_KeyPress);
            // 
            // msMain
            // 
            this.msMain.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.msMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmAide});
            this.msMain.Location = new System.Drawing.Point(0, 0);
            this.msMain.Name = "msMain";
            this.msMain.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.msMain.Size = new System.Drawing.Size(960, 28);
            this.msMain.TabIndex = 0;
            this.msMain.Text = "menuStrip1";
            // 
            // tsmAide
            // 
            this.tsmAide.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmAideAPropos});
            this.tsmAide.Name = "tsmAide";
            this.tsmAide.Size = new System.Drawing.Size(28, 24);
            this.tsmAide.Text = "?";
            // 
            // tsmAideAPropos
            // 
            this.tsmAideAPropos.Name = "tsmAideAPropos";
            this.tsmAideAPropos.Size = new System.Drawing.Size(144, 26);
            this.tsmAideAPropos.Text = "A Propos";
            this.tsmAideAPropos.Click += new System.EventHandler(this.tsmAideAPropos_Click);
            // 
            // btnAjouter
            // 
            this.btnAjouter.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnAjouter.Enabled = false;
            this.btnAjouter.Location = new System.Drawing.Point(12, 68);
            this.btnAjouter.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAjouter.Name = "btnAjouter";
            this.btnAjouter.Size = new System.Drawing.Size(101, 38);
            this.btnAjouter.TabIndex = 2;
            this.btnAjouter.Text = "Ajouter";
            this.btnAjouter.UseVisualStyleBackColor = true;
            this.btnAjouter.Click += new System.EventHandler(this.btnAjouter_Click);
            // 
            // btnSupprimer
            // 
            this.btnSupprimer.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnSupprimer.Enabled = false;
            this.btnSupprimer.Location = new System.Drawing.Point(119, 68);
            this.btnSupprimer.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSupprimer.Name = "btnSupprimer";
            this.btnSupprimer.Size = new System.Drawing.Size(107, 38);
            this.btnSupprimer.TabIndex = 3;
            this.btnSupprimer.Text = "Supprimer";
            this.btnSupprimer.UseVisualStyleBackColor = true;
            this.btnSupprimer.Click += new System.EventHandler(this.btnSupprimer_Click);
            // 
            // cbxAfficher
            // 
            this.cbxAfficher.AutoSize = true;
            this.cbxAfficher.Location = new System.Drawing.Point(67, 112);
            this.cbxAfficher.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbxAfficher.Name = "cbxAfficher";
            this.cbxAfficher.Size = new System.Drawing.Size(78, 21);
            this.cbxAfficher.TabIndex = 4;
            this.cbxAfficher.Text = "Afficher";
            this.cbxAfficher.UseVisualStyleBackColor = true;
            // 
            // lsbFonctions
            // 
            this.lsbFonctions.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lsbFonctions.FormattingEnabled = true;
            this.lsbFonctions.ItemHeight = 16;
            this.lsbFonctions.Location = new System.Drawing.Point(12, 139);
            this.lsbFonctions.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lsbFonctions.Name = "lsbFonctions";
            this.lsbFonctions.Size = new System.Drawing.Size(215, 356);
            this.lsbFonctions.TabIndex = 5;
            this.lsbFonctions.SelectedIndexChanged += new System.EventHandler(this.lsbFonctions_SelectedIndexChanged);
            // 
            // gbxProperties
            // 
            this.gbxProperties.Controls.Add(this.btnValiderModif);
            this.gbxProperties.Controls.Add(this.tbxModifFonction);
            this.gbxProperties.Controls.Add(this.lblZeros);
            this.gbxProperties.Controls.Add(this.lblInfoZero);
            this.gbxProperties.Controls.Add(this.lblOrdonnee);
            this.gbxProperties.Controls.Add(this.lblInfoOrdonnee);
            this.gbxProperties.Controls.Add(this.lblSommet);
            this.gbxProperties.Controls.Add(this.lblInfoSommet);
            this.gbxProperties.Controls.Add(this.lblColor);
            this.gbxProperties.Controls.Add(this.btnColor);
            this.gbxProperties.Enabled = false;
            this.gbxProperties.Location = new System.Drawing.Point(16, 502);
            this.gbxProperties.Margin = new System.Windows.Forms.Padding(4);
            this.gbxProperties.Name = "gbxProperties";
            this.gbxProperties.Padding = new System.Windows.Forms.Padding(4);
            this.gbxProperties.Size = new System.Drawing.Size(212, 230);
            this.gbxProperties.TabIndex = 6;
            this.gbxProperties.TabStop = false;
            this.gbxProperties.Text = "Propriétés";
            // 
            // btnValiderModif
            // 
            this.btnValiderModif.Location = new System.Drawing.Point(65, 178);
            this.btnValiderModif.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnValiderModif.Name = "btnValiderModif";
            this.btnValiderModif.Size = new System.Drawing.Size(75, 33);
            this.btnValiderModif.TabIndex = 13;
            this.btnValiderModif.Text = "Valider";
            this.btnValiderModif.UseVisualStyleBackColor = true;
            this.btnValiderModif.Click += new System.EventHandler(this.btnValiderModif_Click);
            // 
            // tbxModifFonction
            // 
            this.tbxModifFonction.Location = new System.Drawing.Point(33, 151);
            this.tbxModifFonction.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxModifFonction.Name = "tbxModifFonction";
            this.tbxModifFonction.Size = new System.Drawing.Size(145, 22);
            this.tbxModifFonction.TabIndex = 12;
            // 
            // lblZeros
            // 
            this.lblZeros.AutoSize = true;
            this.lblZeros.Location = new System.Drawing.Point(148, 123);
            this.lblZeros.Name = "lblZeros";
            this.lblZeros.Size = new System.Drawing.Size(31, 17);
            this.lblZeros.TabIndex = 11;
            this.lblZeros.Text = "N/A";
            // 
            // lblInfoZero
            // 
            this.lblInfoZero.AutoSize = true;
            this.lblInfoZero.Location = new System.Drawing.Point(12, 123);
            this.lblInfoZero.Name = "lblInfoZero";
            this.lblInfoZero.Size = new System.Drawing.Size(57, 17);
            this.lblInfoZero.TabIndex = 11;
            this.lblInfoZero.Text = "Zéros : ";
            // 
            // lblOrdonnee
            // 
            this.lblOrdonnee.AutoSize = true;
            this.lblOrdonnee.Location = new System.Drawing.Point(148, 94);
            this.lblOrdonnee.Name = "lblOrdonnee";
            this.lblOrdonnee.Size = new System.Drawing.Size(31, 17);
            this.lblOrdonnee.TabIndex = 10;
            this.lblOrdonnee.Text = "N/A";
            // 
            // lblInfoOrdonnee
            // 
            this.lblInfoOrdonnee.AutoSize = true;
            this.lblInfoOrdonnee.Location = new System.Drawing.Point(12, 94);
            this.lblInfoOrdonnee.Name = "lblInfoOrdonnee";
            this.lblInfoOrdonnee.Size = new System.Drawing.Size(91, 17);
            this.lblInfoOrdonnee.TabIndex = 10;
            this.lblInfoOrdonnee.Text = "Ordonnées : ";
            // 
            // lblSommet
            // 
            this.lblSommet.AutoSize = true;
            this.lblSommet.Location = new System.Drawing.Point(148, 65);
            this.lblSommet.Name = "lblSommet";
            this.lblSommet.Size = new System.Drawing.Size(31, 17);
            this.lblSommet.TabIndex = 9;
            this.lblSommet.Text = "N/A";
            // 
            // lblInfoSommet
            // 
            this.lblInfoSommet.AutoSize = true;
            this.lblInfoSommet.Location = new System.Drawing.Point(12, 65);
            this.lblInfoSommet.Name = "lblInfoSommet";
            this.lblInfoSommet.Size = new System.Drawing.Size(71, 17);
            this.lblInfoSommet.TabIndex = 9;
            this.lblInfoSommet.Text = "Sommet : ";
            // 
            // lblColor
            // 
            this.lblColor.AutoSize = true;
            this.lblColor.Location = new System.Drawing.Point(12, 36);
            this.lblColor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblColor.Name = "lblColor";
            this.lblColor.Size = new System.Drawing.Size(69, 17);
            this.lblColor.TabIndex = 8;
            this.lblColor.Text = "Couleur : ";
            // 
            // btnColor
            // 
            this.btnColor.Location = new System.Drawing.Point(148, 23);
            this.btnColor.Margin = new System.Windows.Forms.Padding(4);
            this.btnColor.Name = "btnColor";
            this.btnColor.Size = new System.Drawing.Size(31, 28);
            this.btnColor.TabIndex = 7;
            this.btnColor.UseVisualStyleBackColor = true;
            this.btnColor.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // pbxGraphics
            // 
            this.pbxGraphics.Location = new System.Drawing.Point(235, 32);
            this.pbxGraphics.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbxGraphics.Name = "pbxGraphics";
            this.pbxGraphics.Size = new System.Drawing.Size(700, 700);
            this.pbxGraphics.TabIndex = 7;
            this.pbxGraphics.TabStop = false;
            this.pbxGraphics.Paint += new System.Windows.Forms.PaintEventHandler(this.pbxGraphics_Paint);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 500;
            // 
            // frmMainFonction
            // 
            this.AcceptButton = this.btnAjouter;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(960, 753);
            this.Controls.Add(this.pbxGraphics);
            this.Controls.Add(this.gbxProperties);
            this.Controls.Add(this.lsbFonctions);
            this.Controls.Add(this.cbxAfficher);
            this.Controls.Add(this.btnSupprimer);
            this.Controls.Add(this.btnAjouter);
            this.Controls.Add(this.tbxFonctionUser);
            this.Controls.Add(this.msMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.msMain;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.Name = "frmMainFonction";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calcul de fontions";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMainFonction_FormClosing);
            this.Load += new System.EventHandler(this.frmMainFonction_Load);
            this.msMain.ResumeLayout(false);
            this.msMain.PerformLayout();
            this.gbxProperties.ResumeLayout(false);
            this.gbxProperties.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGraphics)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbxFonctionUser;
        private System.Windows.Forms.MenuStrip msMain;
        private System.Windows.Forms.ToolStripMenuItem tsmAide;
        private System.Windows.Forms.ToolStripMenuItem tsmAideAPropos;
        private System.Windows.Forms.Button btnAjouter;
        private System.Windows.Forms.Button btnSupprimer;
        private System.Windows.Forms.CheckBox cbxAfficher;
          public System.Windows.Forms.ListBox lsbFonctions;
          private System.Windows.Forms.GroupBox gbxProperties;
          private System.Windows.Forms.Button btnColor;
          private System.Windows.Forms.Label lblColor;
          private System.Windows.Forms.ColorDialog cdlColorFonction;
          private System.Windows.Forms.Label lblZeros;
          private System.Windows.Forms.Label lblInfoZero;
          private System.Windows.Forms.Label lblOrdonnee;
          private System.Windows.Forms.Label lblInfoOrdonnee;
          private System.Windows.Forms.Label lblSommet;
          private System.Windows.Forms.Label lblInfoSommet;
          private System.Windows.Forms.TextBox tbxModifFonction;
          private System.Windows.Forms.PictureBox pbxGraphics;
          private System.Windows.Forms.Button btnValiderModif;
          private System.Windows.Forms.Timer timer1;
    }
}

